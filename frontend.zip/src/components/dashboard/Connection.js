import React, { Component } from "react";

export default class Connection extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: []
    };
  }

  render() {
    return (
      <div>
        <div class="container">
          <div class="row">
            <div class="col-sm-9">
              <div class="card">
                <div class="card-header">
                  <b>My Connections And notification </b>
                </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="card">
                <div class="card-body">
                  <h5>
                    <b>Suggetions</b>
                  </h5>
                  <hr />
                  <a>
                    <h6>react js</h6>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
