import React from "react";

const Clientjobhistory = async () => {
  return (
    <div>
      <h1>dasdasda</h1>
    </div>
  );
};

export default Clientjobhistory;
