module.exports = app => {
  const usercontroller = require("../../controller/usercontroller");
  app.post("/api/users/register", usercontroller.registeruser);
  app.post("/api/users/login", usercontroller.loginuser);
  app.get("/api/users/getalluser", usercontroller.getallusers);
  app.get("/api/users/getuser/:id", usercontroller.getuserbyids);
  app.patch("/api/user/update/:id", usercontroller.updateuser);
  app.post("/api/user/resettocken", usercontroller.resettocken);
};
