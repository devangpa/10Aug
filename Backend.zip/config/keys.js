module.exports = {
  mongoURI: 'mongodb://devo:devo8688@ds251948.mlab.com:51948/users',
  secretOrKey: 'secret',
};
