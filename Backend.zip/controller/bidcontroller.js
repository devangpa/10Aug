const bid = require("../model/Biding");
const job = require("../model/Job");
const user = require("../model/User");
const notification = require("../model/Notification");
var nodemailer = require("nodemailer");
var transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "rs2321994@gmail.com",
    pass: "Devang@8688"
  }
});

exports.createabid = async (req, res) => {
  const data = req.body;
  try {
    const savebeed = await bid.create(data);

    console.log(savebeed.Bidingpostid);

    let JobqueryObj = { _id: savebeed.Bidingpostid };
    let JobcraetorObj = { _id: savebeed.jobcreatoruserID };
    let BidderObj = { _id: savebeed.BiderUserID };

    console.log(JobqueryObj);
    console.log(JobcraetorObj);
    console.log(BidderObj);
    const FindJJobobj = await job.findById(savebeed.Bidingpostid);
    const jobcreatorUser = await user.findById(savebeed.jobcreatoruserID);
    const biddderUser = await user.findById(savebeed.BiderUserID);

    const notificationObj = {
      NotificationUserId: savebeed.jobcreatoruserID,
      NotificationMessage: `you get Bid from ${biddderUser.name}`
    };

    const Notificationcreator = await notification.create(notificationObj);

    console.log(biddderUser.email);

    const mailOptions = {
      from: "rs2321994@gmail.com", // sender address
      to: jobcreatorUser.email, // list of receivers
      subject: `Regarding Your Post For ${FindJJobobj.jobtitle}`, // Subject line
      html: `<p>Dear User , On Your Requirnment ${biddderUser.name} Would Like to Do Work On${savebeed.BidingPrice} </p>` // plain text body
    };

    const sendmail = await transporter.sendMail(mailOptions);
    console.log(sendmail);

    // {
    //     "Bidingpostid":"5f23df5229cf0120a8a4c946",
    //     "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ":"5f15362038097d33cce92c90",
    //     "BidingDescription":"asdasdasdasasdasdasdasdasd",
    //     "BidingPrice":"65",
    //     "jobposteduserID":"5f191836568121324c7a577c"
    // }
    res
      .status(200)
      .send({ Message: "Sucesfully BId sucessfull", data: savebeed });
  } catch (err) {
    res
      .status(400)
      .send({ Message: "Not Able to Bid On this Project", data: err });
  }
};

exports.getadatabybiderID = async (req, res) => {
  const ID = req.params.id;
  const findObj = { BiderUserID: ID };
  try {
    const Data = await bid.find(findObj);
    res.status(200).send({ Message: "SucessFully Fetched a data", data: Data });
  } catch (err) {
    res
      .status(400)
      .send({ Message: "Not Able to Bid On this Project", data: err });
  }
};
exports.ChakeBedding = async (req, res) => {
  console.log(req.params.id);
  const ID = req.params.id;
  const findObj = { jobposteduserID: ID };
  //data which is send by JOB ID
  try {
    const Data = await bid.find(findObj);

    res.status(200).send({ Message: "SucessFully Fetched a data", data: Data });
  } catch (err) {
    res
      .status(400)
      .send({ Message: "Not Able to Bid On this Project", data: err });
  }
};
